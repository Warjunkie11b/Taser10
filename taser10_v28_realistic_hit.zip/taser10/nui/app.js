const hud = document.getElementById('hud');
const carts = document.getElementById('cartridges');
const statusEl = document.getElementById('status');
const probeEl = document.getElementById('probe');
const targetEl = document.getElementById('target');
const resourceName = typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'taser10';
const asset = (name) => `https://cfx-nui-${resourceName}/sounds/${name}`;
const sounds = {
  fire: new Audio(asset('taser_fire.wav')),
  hit: new Audio(asset('taser_hit.wav')),
  charge: new Audio(asset('taser_aim.wav')),
  reenergize: new Audio(asset('taser_reenergize.wav')),
  reload: new Audio(asset('taser_reload.wav')),
  remoteCharge: new Audio(asset('taser_aim.wav'))
};
Object.values(sounds).forEach(a => {
  a.preload = 'auto';
  a.playsInline = true;
});
let audioUnlocked = false;
function unlockAudio() {
  if (audioUnlocked) return;
  audioUnlocked = true;
  // Prime the CEF audio elements from a real user input event.
  Object.values(sounds).forEach(a => {
    const oldMuted = a.muted;
    a.muted = true;
    const p = a.play();
    if (p && p.catch) p.catch(() => {});
    setTimeout(() => {
      a.pause();
      a.currentTime = 0;
      a.muted = oldMuted;
    }, 40);
  });
}
document.addEventListener('mousedown', unlockAudio, {passive:true});
document.addEventListener('keydown', unlockAudio, {passive:true});
document.addEventListener('touchstart', unlockAudio, {passive:true});
let chargePlaying = false;
const remoteChargeSources = new Set();
let dragging = false;
let dragX = 0, dragY = 0;
let pos = JSON.parse(localStorage.getItem('taser10HudPos') || 'null');
let hudVisible = false;
let editMode = false;

function applyPosition() {
  if (!pos) return;
  hud.style.left = pos.x + 'px';
  hud.style.top = pos.y + 'px';
  hud.style.right = 'auto';
  hud.style.bottom = 'auto';
}
applyPosition();

function render(d) {
  hudVisible = true;
  hud.classList.remove('hidden');
  carts.innerHTML = '';
  for (let i = 1; i <= 10; i++) {
    const x = document.createElement('span');
    x.className = 'cart ' + (i <= (d.shots ?? 10) ? 'live' : 'fired');
    carts.appendChild(x);
  }
  statusEl.textContent = d.status || 'READY';
  const count = d.connectionCount || 0;
  probeEl.textContent = count ? `${count} PROBE${count === 1 ? '' : 'S'} CONNECTED` : 'NO PROBE';
  targetEl.textContent = d.target || '--';
  statusEl.classList.toggle('pulse', ['FIRING','RELOADING','RE-ENERGIZING'].some(x => (d.status || '').startsWith(x)));
}

function stopCharge() {
  if (!chargePlaying) return;
  sounds.charge.pause();
  sounds.charge.currentTime = 0;
  chargePlaying = false;
}

function play(name, volume) {
  const audio = sounds[name];
  if (!audio) return;
  audio.loop = false;
  audio.pause();
  audio.currentTime = 0;
  audio.volume = Math.max(0, Math.min(1, volume ?? 0.75));
  const p = audio.play();
  if (p && p.catch) {
    p.catch(() => {
      // Retry after the browser has had a chance to unlock CEF audio.
      setTimeout(() => {
        audio.currentTime = 0;
        const retry = audio.play();
        if (retry && retry.catch) retry.catch(() => {});
      }, 75);
    });
  }
}

window.addEventListener('message', e => {
  const d = e.data || {};
  if (d.action === 'show' || d.action === 'update') render(d);
  if (d.action === 'hide') { hudVisible = false; hud.classList.add('hidden'); stopCharge(); }
  if (d.action === 'show') { hudVisible = true; hud.classList.remove('hidden'); }
  if (d.action === 'editMode') editMode = !!d.active;
  if (d.action === 'sound') play(d.name || 'fire', d.volume);
  if (d.action === 'remoteAim') {
    const source = String(d.source ?? 'unknown');
    if (d.active) {
      // Play exactly once when this nearby player first starts aiming.
      // Repeated network updates while they remain aimed must not replay it.
      if (remoteChargeSources.has(source)) return;
      remoteChargeSources.add(source);
      const audio = sounds.remoteCharge;
      audio.loop = false;
      audio.volume = Math.max(0, Math.min(1, d.volume ?? 0.5));
      audio.pause();
      audio.currentTime = 0;
      const p = audio.play();
      if (p && p.catch) p.catch(() => {});
    } else {
      remoteChargeSources.delete(source);
      // The sound is intentionally not looped, so there is nothing to stop.
      // Resetting here prepares it for the next aim event.
      if (remoteChargeSources.size === 0) {
        sounds.remoteCharge.pause();
        sounds.remoteCharge.currentTime = 0;
      }
    }
  }
  if (d.action === 'aim') {
    if (d.active) {
      // Play exactly once at the beginning of each aim. Do not loop.
      const audio = sounds.charge;
      audio.loop = false;
      audio.volume = Math.max(0, Math.min(1, d.volume ?? 0.75));
      if (!chargePlaying) {
        chargePlaying = true;
        audio.pause();
        audio.currentTime = 0;
        const p = audio.play();
        if (p && p.catch) p.catch(() => {});
      }
    } else {
      stopCharge();
    }
  }
});

document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && editMode) {
    editMode = false;
    fetch(`https://${GetParentResourceName()}/closeEdit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: '{}'
    }).catch(() => {});
  }
});

hud.addEventListener('mousedown', e => {
  if (e.button !== 0) return;
  dragging = true;
  const r = hud.getBoundingClientRect();
  dragX = e.clientX - r.left;
  dragY = e.clientY - r.top;
  e.preventDefault();
});
window.addEventListener('mousemove', e => {
  if (!dragging) return;
  const x = Math.max(0, Math.min(window.innerWidth - hud.offsetWidth, e.clientX - dragX));
  const y = Math.max(0, Math.min(window.innerHeight - hud.offsetHeight, e.clientY - dragY));
  hud.style.left = x + 'px';
  hud.style.top = y + 'px';
  hud.style.right = 'auto';
  hud.style.bottom = 'auto';
  pos = {x, y};
});
window.addEventListener('mouseup', () => {
  if (!dragging) return;
  dragging = false;
  localStorage.setItem('taser10HudPos', JSON.stringify(pos));
});

// Double-click the HUD to reset its position.
hud.addEventListener('dblclick', () => {
  pos = null;
  localStorage.removeItem('taser10HudPos');
  hud.style.left = '';
  hud.style.top = '';
  hud.style.right = '3.2vw';
  hud.style.bottom = '8.5vh';
});
