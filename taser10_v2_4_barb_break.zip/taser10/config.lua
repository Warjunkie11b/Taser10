Config = {}
-- Use GTA's native stun-gun hash so the supplied w_pi_stungun archetype is reliably mounted/aimed.
Config.Weapon = 'WEAPON_STUNGUN'
Config.MaxShots = 10
Config.FireCooldown = 850
Config.ReloadTime = 2800
Config.StunDuration = 5000
Config.ReEnergizeDuration = 5000
Config.MaxRange = 35.0
-- Barbs disconnect/break off when the connected target gets more than 15 feet from the shooter.
Config.BarbBreakDistance = 15.0
Config.LaserRange = 35.0
Config.EnableProbeEffects = false
Config.EnableNUI = true
Config.SoundVolume = 0.75
