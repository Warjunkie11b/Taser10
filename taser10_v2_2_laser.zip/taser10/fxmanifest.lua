fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'Custom FiveM Resource'
description 'TASER 10-style FiveM weapon resource'
version '2.0.0'

files {
    'data/weapons.meta',
    'nui/index.html',
    'nui/style.css',
    'nui/app.js',
    'sounds/taser_fire.wav',
    'sounds/taser_charge.wav',
    'sounds/taser_aim.wav',
    'sounds/taser_reenergize.wav',
    'sounds/taser_reload.wav'
}

data_file 'WEAPONINFO_FILE_PATCH' 'data/weapons.meta'

client_scripts {
    'config.lua',
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}

ui_page 'nui/index.html'
