local weaponHash = joaat(Config.Weapon)
local shots = Config.MaxShots
local lastShot = 0
local reloading = false
local connections = {}
local connectedTarget = nil
local connectedTargetName = '--'
local connectedUntil = 0
local charging = false
local hudVisible = false
local laserEnabled = false
local remoteAimSources = {}
local remoteConnections = {}
local statusOpen = false

local function nui(action, data)
    if not Config.EnableNUI then return end
    data = data or {}
    data.action = action
    SendNUIMessage(data)
end

local function connectionCount()
    local n = 0
    for _, c in pairs(connections) do
        if DoesEntityExist(c.ped) and not IsEntityDead(c.ped) then n = n + 1 end
    end
    return n
end

local function syncConnectionDisplay(text)
    local names = {}
    for _, c in pairs(connections) do
        if DoesEntityExist(c.ped) and not IsEntityDead(c.ped) then names[#names+1] = c.name end
    end
    table.sort(names)
    nui('update', {
        shots = shots,
        probe = #names > 0,
        target = (#names > 0 and table.concat(names, ', ')) or '--',
        status = text or (#names > 0 and ('CONNECTED: '..#names) or 'READY'),
        connectionCount = #names
    })
end

local function notify(msg)
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName(msg)
    EndTextCommandThefeedPostTicker(false, false)
end

local function playSound(name, volume)
    if not Config.EnableNUI then return end
    SendNUIMessage({ action = 'sound', name = name, volume = volume or Config.SoundVolume })
end

local function playStockTaserSound()
    -- GTA V's built-in stun-gun audio is part of the weapon audio bank.
    -- Trigger the built-in weapon fire event without actually firing the weapon.
    local ped = PlayerPedId()
    PlaySoundFromEntity(-1, 'Fire', ped, 'WEAPON_STUNGUN', false, 0)
end

local function getAimedPed()
    local ok, entity = GetEntityPlayerIsFreeAimingAt(PlayerId())
    if ok and DoesEntityExist(entity) and IsEntityAPed(entity) and not IsEntityDead(entity) then
        return entity
    end
    return nil
end

local function getTargetName(ped)
    local player = NetworkGetPlayerIndexFromPed(ped)
    if player ~= -1 then return GetPlayerName(player) or 'TARGET' end
    return 'TARGET'
end

local function stunPed(ped, duration)
    if not DoesEntityExist(ped) or IsEntityDead(ped) then return false end
    local player = NetworkGetPlayerIndexFromPed(ped)
    if player ~= -1 then
        TriggerServerEvent('taser10:stun', GetPlayerServerId(player), duration)
    else
        SetPedToRagdoll(ped, duration, duration, 0, false, false, false)
    end
    return true
end

local function reloadTaser()
    if reloading or shots >= Config.MaxShots then return end
    reloading = true
    for _, c in pairs(connections) do
        if c.ped and DoesEntityExist(c.ped) then
            local targetPlayer = NetworkGetPlayerIndexFromPed(c.ped)
            if targetPlayer ~= -1 then
                TriggerServerEvent('taser10:probeDisconnected', GetPlayerServerId(targetPlayer))
            end
        end
    end
    connections = {}
    connectedTarget = nil
    connectedTargetName = '--'
    connectedUntil = 0
    nui('update', { shots = shots, probe = false, target = connectedTargetName, status = 'RELOADING', connectionCount = 0 })
    playSound('reload', Config.SoundVolume)

    CreateThread(function()
        Wait(Config.ReloadTime)
        shots = Config.MaxShots
        reloading = false
        nui('update', { shots = shots, probe = false, target = connectedTargetName, status = 'READY', connectionCount = 0 })
        notify('~b~TASER 10~s~ reloaded — 10 cartridges available')
    end)
end

local function fireTaser()
    if reloading or shots <= 0 then
        if shots <= 0 then notify('~r~TASER 10 EMPTY~s~ — press ~y~R~s~ to reload') end
        return
    end

    local now = GetGameTimer()
    if now - lastShot < Config.FireCooldown then return end
    lastShot = now
    shots = shots - 1

    -- Tell the server this officer discharged the TASER so nearby/other officers
    -- can see it in the recent-discharge status panel.
    TriggerServerEvent('taser10:discharged')

    -- Force the native stun-gun trigger to remain suppressed; the custom NUI sound is played separately.
    playSound('fire', Config.SoundVolume)
    syncConnectionDisplay('FIRING')

    local shooter = PlayerPedId()
    local target = getAimedPed()
    if target then
        local dist = #(GetEntityCoords(shooter) - GetEntityCoords(target))
        if dist <= Config.MaxRange then
            local name = getTargetName(target)
            if stunPed(target, Config.StunDuration) then
                -- Realistic electrical discharge sound only when a barb connection is made.
                playSound('hit', Config.SoundVolume)
                local key = NetworkGetPlayerIndexFromPed(target)
                if key == -1 then key = 'ped:' .. tostring(target) end
                connections[key] = {
                    ped = target,
                    name = name,
                    untilTime = GetGameTimer() + Config.StunDuration
                }
                local targetPlayer = NetworkGetPlayerIndexFromPed(target)
                if targetPlayer ~= -1 then
                    TriggerServerEvent('taser10:probeConnected', GetPlayerServerId(targetPlayer))
                end
                connectedTarget = target
                connectedTargetName = name
                connectedUntil = GetGameTimer() + Config.StunDuration
                syncConnectionDisplay('CONNECTED: '..connectionCount())
            end
        else
            syncConnectionDisplay('OUT OF RANGE')
        end
    else
        syncConnectionDisplay('NO CONNECTION')
    end

    if shots == 0 then
        notify('~r~TASER 10 EMPTY~s~ — press ~y~R~s~ to reload')
    end
end

local function reEnergize()
    if reloading then return end

    local valid = {}
    for key, c in pairs(connections) do
        if DoesEntityExist(c.ped) and not IsEntityDead(c.ped) then
            valid[#valid+1] = c
        else
            connections[key] = nil
        end
    end

    if #valid == 0 then
        syncConnectionDisplay('READY')
        return
    end

    playStockTaserSound()
    syncConnectionDisplay('RE-ENERGIZING: '..#valid)

    for _, c in ipairs(valid) do
        stunPed(c.ped, Config.ReEnergizeDuration)
        c.untilTime = GetGameTimer() + Config.ReEnergizeDuration
    end

    CreateThread(function()
        Wait(Config.ReEnergizeDuration)
        syncConnectionDisplay('CONNECTED: '..connectionCount())
    end)
end

RegisterNetEvent('taser10:applyStun', function(duration)
    local ped = PlayerPedId()
    SetPedToRagdoll(ped, duration, duration, 0, false, false, false)
    ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.12)
    CreateThread(function()
        local finish = GetGameTimer() + duration
        while GetGameTimer() < finish do
            DisablePlayerFiring(PlayerId(), true)
            DisableControlAction(0, 24, true)
            DisableControlAction(0, 25, true)
            DisableControlAction(0, 37, true)
            DisableControlAction(0, 45, true)
            Wait(0)
        end
    end)
end)

local function showHud()
    if hudVisible then return end
    hudVisible = true
    nui('show', {
        shots = shots,
        probe = connectionCount() > 0,
        target = connectedTargetName,
        status = reloading and 'RELOADING' or 'READY'
    })
end

local function setLaser(enabled)
    laserEnabled = enabled and true or false
end

local function toggleLaser()
    setLaser(not laserEnabled)
    notify(laserEnabled and '~r~TASER laser/light ON~s~' or '~w~TASER laser/light OFF~s~')
end

local function drawLaserLight(ped)
    if not laserEnabled or not IsPlayerFreeAiming(PlayerId()) then return end

    -- Use the actual TASER weapon entity so the laser originates from the
    -- front of the weapon rather than the officer's hand/body.
    local weaponEntity = GetCurrentPedWeaponEntityIndex(ped)
    if not weaponEntity or weaponEntity == 0 or not DoesEntityExist(weaponEntity) then return end

    -- Small forward offset from the weapon muzzle/front.
    local origin = GetOffsetFromEntityInWorldCoords(weaponEntity, 0.0, 0.24, 0.035)
    local forward = GetEntityForwardVector(weaponEntity)
    local destination = origin + forward * Config.LaserRange

    -- Realistic laser behavior: the beam itself is normally not visible;
    -- project a tiny red dot onto whatever surface/person is being aimed at.
    local ray = StartShapeTestRay(
        origin.x, origin.y, origin.z,
        destination.x, destination.y, destination.z,
        511, ped, 7
    )
    local _, hit, hitCoords = GetShapeTestResult(ray)

    if hit == 1 then
        -- Tiny, sharp red laser dot. Scale stays small at all distances.
        DrawMarker(
            28,
            hitCoords.x, hitCoords.y, hitCoords.z + 0.001,
            0.0, 0.0, 0.0,
            0.0, 0.0, 0.0,
            0.010, 0.010, 0.010,
            255, 0, 0, 235,
            false, true, 2, false, nil, nil, false
        )

        -- Very subtle glow around the dot, rather than a large visible beam.
        DrawLightWithRange(hitCoords.x, hitCoords.y, hitCoords.z, 255, 0, 0, 0.18, 0.10)
    end
end

local function getTaserWireOrigin(ped)
    local weaponEntity = GetCurrentPedWeaponEntityIndex(ped)
    if weaponEntity and weaponEntity ~= 0 and DoesEntityExist(weaponEntity) then
        -- Origin is on the front of the actual TASER model, not the officer's hand.
        return GetOffsetFromEntityInWorldCoords(weaponEntity, 0.0, 0.18, 0.02)
    end
    return GetPedBoneCoords(ped, 57005, 0.16, 0.02, 0.0)
end

local function drawProbeAtTarget(target, shooterCoords, attachOffset)
    local chest = GetPedBoneCoords(target, 24816, 0.0, 0.0, 0.0)
    local attach = chest + attachOffset
    local away = attach - shooterCoords
    local len = #(away)
    if len < 0.001 then return end
    local dir = away / len

    -- A narrow, metallic-looking probe made from lines rather than a spherical marker.
    local shaftLen = 0.11
    local shaftEnd = attach + dir * shaftLen
    DrawLine(attach.x, attach.y, attach.z, shaftEnd.x, shaftEnd.y, shaftEnd.z, 205, 205, 205, 255)

    -- Two small barb/fletching lines at the rear of the dart.
    local side = vector3(-dir.y, dir.x, 0.0)
    if #(side) < 0.001 then side = vector3(1.0, 0.0, 0.0) else side = side / #(side) end
    local barbBase = attach + dir * 0.025
    local barbTipA = barbBase - dir * 0.035 + side * 0.025
    local barbTipB = barbBase - dir * 0.035 - side * 0.025
    DrawLine(barbBase.x, barbBase.y, barbBase.z, barbTipA.x, barbTipA.y, barbTipA.z, 175, 175, 175, 255)
    DrawLine(barbBase.x, barbBase.y, barbBase.z, barbTipB.x, barbTipB.y, barbTipB.z, 175, 175, 175, 255)

    -- Tiny bright contact point at the probe tip (not a large ball).
    local tip = attach + dir * 0.012
    DrawMarker(28, tip.x, tip.y, tip.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
        0.012, 0.012, 0.012, 210, 210, 210, 240, false, false, 2, false, nil, nil, false)
end

local function drawProbeConnection(shooter, target)
    if not DoesEntityExist(shooter) or not DoesEntityExist(target) then return end
    if IsEntityDead(shooter) or IsEntityDead(target) then return end

    local origin = getTaserWireOrigin(shooter)
    local targetCoords = GetEntityCoords(target)
    local dist = #(GetEntityCoords(shooter) - targetCoords)
    local maxDistance = Config.ProbeWireDistance or Config.BarbBreakDistance or 15.0
    if dist > maxDistance then return end

    -- Two independent wires leave the front of the TASER and terminate at two darts.
    local originA = origin + vector3(0.020, 0.0, 0.020)
    local originB = origin + vector3(-0.020, 0.0, -0.005)
    local chest = GetPedBoneCoords(target, 24816, 0.0, 0.0, 0.0)
    local probeA = chest + vector3(0.15, 0.0, 0.08)
    local probeB = chest + vector3(-0.15, 0.0, -0.05)

    -- Slight sag makes the wires look like flexible cable instead of laser beams.
    local sagA = vector3(0.0, 0.0, -math.min(0.22, dist * 0.012))
    local sagB = vector3(0.0, 0.0, -math.min(0.18, dist * 0.010))
    local midA = (originA + probeA) * 0.5 + sagA
    local midB = (originB + probeB) * 0.5 + sagB

    DrawLine(originA.x, originA.y, originA.z, midA.x, midA.y, midA.z, 25, 25, 25, 245)
    DrawLine(midA.x, midA.y, midA.z, probeA.x, probeA.y, probeA.z, 25, 25, 25, 245)
    DrawLine(originB.x, originB.y, originB.z, midB.x, midB.y, midB.z, 25, 25, 25, 245)
    DrawLine(midB.x, midB.y, midB.z, probeB.x, probeB.y, probeB.z, 25, 25, 25, 245)

    drawProbeAtTarget(target, GetEntityCoords(shooter), vector3(0.15, 0.0, 0.08))
    drawProbeAtTarget(target, GetEntityCoords(shooter), vector3(-0.15, 0.0, -0.05))
end

local function drawProbeEffects(shooter)
    if not Config.EnableProbeEffects then return end

    -- Locally owned connections.
    for _, c in pairs(connections) do
        if DoesEntityExist(c.ped) and not IsEntityDead(c.ped) then
            drawProbeConnection(shooter, c.ped)
        end
    end

    -- Connections owned by every other player are replicated by the server.
    local myServerId = GetPlayerServerId(PlayerId())
    for shooterId, targetIds in pairs(remoteConnections) do
        if tonumber(shooterId) ~= myServerId then
            local shooterPlayer = GetPlayerFromServerId(tonumber(shooterId))
            if shooterPlayer ~= -1 then
                local shooterPed = GetPlayerPed(shooterPlayer)
                if DoesEntityExist(shooterPed) and not IsEntityDead(shooterPed) then
                    for targetId in pairs(targetIds) do
                        local targetPlayer = GetPlayerFromServerId(tonumber(targetId))
                        if targetPlayer ~= -1 then
                            local targetPed = GetPlayerPed(targetPlayer)
                            if DoesEntityExist(targetPed) and not IsEntityDead(targetPed) then
                                drawProbeConnection(shooterPed, targetPed)
                            end
                        end
                    end
                end
            end
        end
    end
end

local function checkBarbConnections(shooter)
    local changed = false
    local maxDistance = Config.BarbBreakDistance or 15.0
    local shooterCoords = GetEntityCoords(shooter)

    for key, c in pairs(connections) do
        if not DoesEntityExist(c.ped) or IsEntityDead(c.ped) then
            connections[key] = nil
            changed = true
        else
            local targetCoords = GetEntityCoords(c.ped)
            local distance = #(shooterCoords - targetCoords)

            -- Once a connected target moves beyond the configured distance,
            -- the barbs are treated as broken/disconnected and that target
            -- can no longer be re-energized.
            if distance > maxDistance then
                connections[key] = nil
                changed = true
                local targetPlayer = NetworkGetPlayerIndexFromPed(c.ped)
                if targetPlayer ~= -1 then
                    TriggerServerEvent('taser10:probeDisconnected', GetPlayerServerId(targetPlayer))
                end
            end
        end
    end

    if changed then
        local count = connectionCount()
        syncConnectionDisplay(count > 0 and ('CONNECTED: '..count) or 'BARBS DISCONNECTED')
    end
end

RegisterNetEvent('taser10:probeConnected', function(shooterServerId, targetServerId)
    shooterServerId = tonumber(shooterServerId)
    targetServerId = tonumber(targetServerId)
    if not shooterServerId or not targetServerId then return end
    remoteConnections[shooterServerId] = remoteConnections[shooterServerId] or {}
    remoteConnections[shooterServerId][targetServerId] = true
end)

RegisterNetEvent('taser10:probeDisconnected', function(shooterServerId, targetServerId)
    shooterServerId = tonumber(shooterServerId)
    targetServerId = tonumber(targetServerId)
    if not shooterServerId then return end
    if targetServerId and remoteConnections[shooterServerId] then
        remoteConnections[shooterServerId][targetServerId] = nil
        if next(remoteConnections[shooterServerId]) == nil then
            remoteConnections[shooterServerId] = nil
        end
    else
        remoteConnections[shooterServerId] = nil
    end
end)

RegisterNetEvent('taser10:remoteAimSound', function(shooterServerId, active)
    shooterServerId = tonumber(shooterServerId)
    if not shooterServerId or shooterServerId == GetPlayerServerId(PlayerId()) then return end

    if not active then
        remoteAimSources[shooterServerId] = nil
        nui('remoteAim', { source = shooterServerId, active = false })
        return
    end

    remoteAimSources[shooterServerId] = true
end)

CreateThread(function()
    while true do
        local myPed = PlayerPedId()
        local myCoords = GetEntityCoords(myPed)
        for serverId in pairs(remoteAimSources) do
            local player = GetPlayerFromServerId(serverId)
            if player == -1 then
                remoteAimSources[serverId] = nil
                nui('remoteAim', { source = serverId, active = false })
            else
                local shooterPed = GetPlayerPed(player)
                if not DoesEntityExist(shooterPed) or IsEntityDead(shooterPed) then
                    remoteAimSources[serverId] = nil
                    nui('remoteAim', { source = serverId, active = false })
                else
                    local dist = #(myCoords - GetEntityCoords(shooterPed))
                    local maxDist = Config.AimSoundRange or 25.0
                    if dist > maxDist then
                        nui('remoteAim', { source = serverId, active = false })
                    else
                        local volume = Config.AimSoundVolume or 0.65
                        volume = volume * math.max(0.0, 1.0 - (dist / maxDist))
                        nui('remoteAim', { source = serverId, active = true, volume = volume })
                    end
                end
            end
        end
        Wait(250)
    end
end)

local function hideHud()
    if not hudVisible then return end
    hudVisible = false
    nui('hide')
    setLaser(false)
    if charging then
        charging = false
        TriggerServerEvent('taser10:aimAudio', false)
        nui('aim', { active = false })
    end
end

CreateThread(function()
    while true do
        local wait = 250
        local ped = PlayerPedId()
        local weapon = GetSelectedPedWeapon(ped)

        if weapon == weaponHash and not IsEntityDead(ped) then
            wait = 0
            showHud()
            checkBarbConnections(ped)
            drawProbeEffects(ped)

            if reloading then
                DisablePlayerFiring(PlayerId(), true)
            end

            -- R = reload. Use disabled-control detection so reload remains reliable
            -- even if another resource temporarily blocks the normal input.
            if IsControlJustPressed(0, 45) or IsDisabledControlJustPressed(0, 45) then
                reloadTaser()
            end

            -- G = re-energize all currently connected targets.
            if IsControlJustPressed(0, 47) or IsDisabledControlJustPressed(0, 47) then
                reEnergize()
            end

            -- Keep native aiming animation/camera intact. Suppress only the actual
            -- attack input so the native stun-gun projectile/audio does not fire.
            if IsPlayerFreeAiming(PlayerId()) then
                -- F toggles the red laser/aim light while the TASER is raised.
                if IsControlJustPressed(0, 23) then
                    toggleLaser()
                end

                if not charging then
                    charging = true
                    TriggerServerEvent('taser10:aimAudio', true)
                    nui('aim', { active = true, volume = Config.SoundVolume })
                end

                drawLaserLight(ped)

                DisableControlAction(0, 24, true)
                if IsDisabledControlJustPressed(0, 24) then
                    fireTaser()
                end
            elseif charging then
                charging = false
                TriggerServerEvent('taser10:aimAudio', false)
                nui('aim', { active = false })
                setLaser(false)
            else
                -- Lowering the TASER automatically turns the laser/light off.
                setLaser(false)
            end
        else
            -- Holstering/switching away from the TASER immediately breaks every
            -- active barb connection. Those connections are permanently removed
            -- for this cartridge deployment, so re-equipping cannot re-energize
            -- the previous targets.
            if next(connections) ~= nil then
                for _, c in pairs(connections) do
                    if c.ped and DoesEntityExist(c.ped) then
                        local targetPlayer = NetworkGetPlayerIndexFromPed(c.ped)
                        if targetPlayer ~= -1 then
                            TriggerServerEvent('taser10:probeDisconnected', GetPlayerServerId(targetPlayer))
                        end
                    end
                end
                connections = {}
                connectedTarget = nil
                connectedTargetName = '--'
                connectedUntil = 0
            end
            hideHud()
        end
        Wait(wait)
    end
end)

AddEventHandler('onClientResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end
    hideHud()
    TriggerServerEvent('taser10:aimAudio', false)
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
end)

exports('GetShots', function() return shots end)
exports('GiveTaser10', function()
    local ped = PlayerPedId()
    GiveWeaponToPed(ped, weaponHash, Config.MaxShots, false, true)
    SetPedAmmo(ped, weaponHash, Config.MaxShots)
    shots = Config.MaxShots
    connections = {}
    syncConnectionDisplay('READY')
end)

RegisterCommand('taser10', function()
    exports['taser10']:GiveTaser10()
end, false)

RegisterNetEvent('taser10:dischargeHistory', function(entries)
    nui('dischargeHistory', { entries = entries or {} })
end)

RegisterNetEvent('taser10:dischargeNotice', function(entry)
    nui('dischargeNotice', { entry = entry })
end)

RegisterCommand('taser10status', function()
    statusOpen = not statusOpen
    nui('statusPanel', { active = statusOpen })
    if statusOpen then
        SetNuiFocus(true, true)
        TriggerServerEvent('taser10:getDischargeHistory')
    else
        SetNuiFocus(false, false)
    end
end, false)

RegisterCommand('taser10move', function()
    nui('editMode', { active = true })
    SetNuiFocus(true, true)
    notify('~b~TASER 10~s~ UI move mode: drag the HUD, then press ~y~ESC~s~')
end, false)

RegisterNUICallback('closeEdit', function(_, cb)
    SetNuiFocus(false, false)
    nui('editMode', { active = false })
    if cb then cb('ok') end
end)

RegisterNUICallback('closeStatus', function(_, cb)
    statusOpen = false
    SetNuiFocus(false, false)
    nui('statusPanel', { active = false })
    if cb then cb('ok') end
end)

RegisterCommand('taser10soundtest', function()
    playSound('fire', Config.SoundVolume)
    notify('~b~TASER 10~s~ custom sound test sent to NUI')
end, false)

RegisterCommand('taser10check', function()
    local ped = PlayerPedId()
    local current = GetSelectedPedWeapon(ped)
    notify(('~b~TASER 10~s~ weapon hash: %s | current: %s'):format(weaponHash, current))
end, false)

RegisterCommand('taser10debug', function()
    notify(('~b~TASER 10~s~ | cartridges: %d/10 | reloading: %s | aiming: %s'):format(shots, tostring(reloading), tostring(IsPlayerFreeAiming(PlayerId()))))
end, false)
