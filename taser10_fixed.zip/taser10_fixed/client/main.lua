local weaponHash = joaat(Config.Weapon)
local WEAPON_STUNGUN = joaat('WEAPON_STUNGUN')
local shots = Config.MaxShots
local lastShot = 0
local reloading = false
local activeProbes = {}

local function nui(action, data)
    if not Config.EnableNUI then return end
    data = data or {}; data.action = action
    SendNUIMessage(data)
end

local function status(probe, target, text)
    nui('update', {shots=shots, probe=probe or false, target=target or '--', status=text or 'READY'})
end

local function notify(msg)
    BeginTextCommandThefeedPost('STRING'); AddTextComponentSubstringPlayerName(msg); EndTextCommandThefeedPostTicker(false, false)
end

local function playTaserSound()
    if Config.SoundVolume <= 0 then return end
    SendNUIMessage({action='sound', volume=Config.SoundVolume})
end

local function reloadTaser()
    if reloading or shots >= Config.MaxShots then return end
    reloading = true; status(false,'--','RELOADING')
    CreateThread(function()
        Wait(Config.ReloadTime)
        shots = Config.MaxShots; reloading = false
        status(false,'--','READY')
        notify('~b~TASER 10~s~ reloaded — 10 cartridges available')
    end)
end

local function stunPed(ped)
    if not DoesEntityExist(ped) or IsEntityDead(ped) then return end
    local player = NetworkGetPlayerIndexFromPed(ped)
    if player ~= -1 then
        TriggerServerEvent('taser10:stun', GetPlayerServerId(player), Config.StunDuration)
    else
        SetPedToRagdoll(ped, Config.StunDuration, Config.StunDuration, 0, false, false, false)
    end
end

RegisterNetEvent('taser10:applyStun', function(duration)
    local ped=PlayerPedId(); SetPedToRagdoll(ped,duration,duration,0,false,false,false); ShakeGameplayCam('SMALL_EXPLOSION_SHAKE',0.12)
    CreateThread(function() local finish=GetGameTimer()+duration while GetGameTimer()<finish do DisablePlayerFiring(PlayerId(),true); DisableControlAction(0,24,true); DisableControlAction(0,25,true); DisableControlAction(0,37,true); DisableControlAction(0,45,true); Wait(0) end end)
end)

CreateThread(function()
    while true do
        local wait=250; local ped=PlayerPedId(); local weapon=GetSelectedPedWeapon(ped)
        if weapon==weaponHash then
            wait=0; nui('show',{shots=shots,probe=#activeProbes>0,target='--',status=reloading and 'RELOADING' or 'READY'})
            if reloading then DisablePlayerFiring(PlayerId(),true) end
            if IsControlJustPressed(0,45) then reloadTaser() end
            if IsPedShooting(ped) then
                local now=GetGameTimer()
                if reloading or shots<=0 or (now-lastShot)<Config.FireCooldown then DisablePlayerFiring(PlayerId(),true)
                else
                    lastShot=now; shots=shots-1; playTaserSound(); status(false,'--','FIRING')
                    local hit,entity=GetEntityPlayerIsFreeAimingAt(PlayerId())
                    if hit and DoesEntityExist(entity) and IsEntityAPed(entity) then
                        local dist=#(GetEntityCoords(ped)-GetEntityCoords(entity))
                        if dist<=Config.MaxRange then
                            stunPed(entity); activeProbes[#activeProbes+1]={target=entity,created=now,expires=now+Config.StunDuration}
                            local targetPlayer=NetworkGetPlayerIndexFromPed(entity); local name=(targetPlayer~=-1 and GetPlayerName(targetPlayer)) or 'TARGET'
                            status(true,name,'CONNECTED')
                        end
                    end
                    if shots==0 then notify('~r~TASER 10 EMPTY~s~ — press ~y~R~s~ to reload') end
                end
            end
        else
            nui('hide')
        end
        Wait(wait)
    end
end)

CreateThread(function()
    while true do Wait(0); if Config.EnableProbeEffects then local ped=PlayerPedId(); for i=#activeProbes,1,-1 do local p=activeProbes[i]; if GetGameTimer()>p.expires or not DoesEntityExist(p.target) then table.remove(activeProbes,i) else local a=GetEntityCoords(ped); local b=GetEntityCoords(p.target); DrawLine(a.x,a.y,a.z+.75,b.x,b.y,b.z+.75,120,190,255,180) end end end end
end)

exports('GetShots',function() return shots end)
exports('GiveTaser10',function() local ped=PlayerPedId(); GiveWeaponToPed(ped,weaponHash,Config.MaxShots,false,true); SetPedAmmo(ped,weaponHash,Config.MaxShots); SetCurrentPedWeapon(ped,weaponHash,true); shots=Config.MaxShots; status(false,'--','READY') end)
RegisterCommand('taser10',function() exports['taser10']:GiveTaser10() end,false)
