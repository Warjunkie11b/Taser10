const hud=document.getElementById('hud'), carts=document.getElementById('cartridges'), statusEl=document.getElementById('status'), probeEl=document.getElementById('probe'), targetEl=document.getElementById('target');
function render(d){hud.classList.remove('hidden');carts.innerHTML='';for(let i=1;i<=10;i++){let x=document.createElement('span');x.className='cart '+(i<=d.shots?'live':'fired');if(d.active===i)x.className+=' active';carts.appendChild(x)}statusEl.textContent=d.status||'READY';probeEl.textContent=d.probe?'PROBE CONNECTED':'NO PROBE';targetEl.textContent=d.target||'--';statusEl.classList.toggle('pulse',d.status==='FIRING'||d.status==='RELOADING')}
window.addEventListener('message',e=>{const d=e.data||{};if(d.action==='show')render(d);if(d.action==='hide')hud.classList.add('hidden');if(d.action==='update')render(d)});

const fire=document.getElementById('fire');
window.addEventListener('message',e=>{if(e.data?.action==='sound'){fire.volume=Math.max(0,Math.min(1,e.data.volume||0.75));fire.currentTime=0;fire.play().catch(()=>{});}});
