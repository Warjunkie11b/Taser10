fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Custom FiveM Resource'
description 'TASER 10-style addon weapon using supplied stun gun assets'
version '1.2.0'

files {
    'data/weapons.meta',
    'nui/index.html',
    'nui/style.css',
    'nui/app.js',
    'sounds/taser_fire.wav'
}

data_file 'WEAPONINFO_FILE_PATCH' 'data/weapons.meta'

client_scripts {
    'config.lua',
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}

ui_page 'nui/index.html'
