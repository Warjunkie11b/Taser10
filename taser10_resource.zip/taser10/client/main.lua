local weaponHash = joaat(Config.Weapon)
local shots = Config.MaxShots
local lastShot = 0
local reloading = false
local stunnedUntil = 0
local activeProbes = {}

local function notify(msg)
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName(msg)
    EndTextCommandThefeedPostTicker(false, false)
end

local function drawText2d(x, y, text, scale)
    SetTextFont(4)
    SetTextScale(scale, scale)
    SetTextColour(255,255,255,230)
    SetTextOutline()
    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(x, y)
end

local function reloadTaser()
    if reloading or shots >= Config.MaxShots then return end
    reloading = true
    CreateThread(function()
        local ped = PlayerPedId()
        FreezeEntityPosition(ped, false)
        Wait(Config.ReloadTime)
        shots = Config.MaxShots
        reloading = false
        notify('~b~TASER 10~s~ reloaded — 10 cartridges available')
    end)
end

local function stunPed(ped)
    if not DoesEntityExist(ped) or IsEntityDead(ped) then return end
    local player = NetworkGetPlayerIndexFromPed(ped)
    if player ~= -1 then
        TriggerServerEvent('taser10:stun', GetPlayerServerId(player), Config.StunDuration)
    else
        SetPedToRagdoll(ped, Config.StunDuration, Config.StunDuration, 0, false, false, false)
    end
end

RegisterNetEvent('taser10:applyStun', function(duration)
    local ped = PlayerPedId()
    stunnedUntil = GetGameTimer() + duration
    SetPedCanRagdoll(ped, true)
    SetPedToRagdoll(ped, duration, duration, 0, false, false, false)
    ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.12)

    CreateThread(function()
        local finish = GetGameTimer() + duration
        while GetGameTimer() < finish do
            DisablePlayerFiring(PlayerId(), true)
            DisableControlAction(0, 24, true)
            DisableControlAction(0, 25, true)
            DisableControlAction(0, 37, true)
            DisableControlAction(0, 45, true)
            Wait(0)
        end
        stunnedUntil = 0
    end)
end)

CreateThread(function()
    while true do
        local wait = 250
        local ped = PlayerPedId()
        local weapon = GetSelectedPedWeapon(ped)

        if weapon == weaponHash then
            wait = 0
            if reloading then
                DisablePlayerFiring(PlayerId(), true)
            end

            if IsControlJustPressed(0, 45) then -- R
                reloadTaser()
            end

            if IsPedShooting(ped) then
                local now = GetGameTimer()
                if reloading or shots <= 0 or (now - lastShot) < Config.FireCooldown then
                    DisablePlayerFiring(PlayerId(), true)
                else
                    lastShot = now
                    shots = shots - 1

                    local hit, entity = GetEntityPlayerIsFreeAimingAt(PlayerId())
                    if hit and DoesEntityExist(entity) and IsEntityAPed(entity) then
                        stunPed(entity)
                        activeProbes[#activeProbes + 1] = {
                            target = entity,
                            created = now,
                            expires = now + Config.StunDuration
                        }
                    end

                    if shots == 0 then
                        notify('~r~TASER 10 EMPTY~s~ — press ~y~R~s~ to reload')
                    end
                end
            end

            drawText2d(0.89, 0.91, string.format('TASER 10  %02d/10', shots), 0.32)
        end

        Wait(wait)
    end
end)

CreateThread(function()
    while true do
        Wait(0)
        if Config.EnableProbeEffects then
            local ped = PlayerPedId()
            for i = #activeProbes, 1, -1 do
                local probe = activeProbes[i]
                if GetGameTimer() > probe.expires or not DoesEntityExist(probe.target) then
                    table.remove(activeProbes, i)
                elseif DoesEntityExist(probe.target) then
                    local a = GetEntityCoords(ped)
                    local b = GetEntityCoords(probe.target)
                    DrawLine(a.x, a.y, a.z + 0.75, b.x, b.y, b.z + 0.75, 120, 190, 255, 180)
                end
            end
        end
    end
end)

exports('GetShots', function()
    return shots
end)

exports('GiveTaser10', function()
    local ped = PlayerPedId()
    GiveWeaponToPed(ped, weaponHash, Config.MaxShots, false, true)
    SetPedAmmo(ped, weaponHash, Config.MaxShots)
    shots = Config.MaxShots
end)

RegisterCommand('taser10', function()
    exports['taser10']:GiveTaser10()
end, false)
