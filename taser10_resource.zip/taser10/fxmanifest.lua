fx_version 'cerulean'
game 'gta5'

lua54 'yes'

author 'Custom FiveM Resource'
description 'TASER 10-style FiveM weapon resource'
version '1.0.0'

files {
    'data/weapons.meta'
}

data_file 'WEAPONINFO_FILE_PATCH' 'data/weapons.meta'

client_scripts {
    'config.lua',
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}
