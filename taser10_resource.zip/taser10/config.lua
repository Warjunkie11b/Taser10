Config = {}

Config.Weapon = 'WEAPON_TASER10'
Config.MaxShots = 10
Config.Range = 30.0
Config.FireCooldown = 850
Config.StunDuration = 5000
Config.ReloadTime = 2200
Config.DrawTime = 650
Config.EnableProbeEffects = true
Config.RequirePoliceJob = false
Config.PoliceJobs = {
    police = true,
    sheriff = true,
    state = true
}

-- Gameplay approximation of a TASER 10. GTA/FiveM does not expose the
-- proprietary TASER 10 hardware/firmware behavior directly.
