const hud = document.getElementById('hud');
const carts = document.getElementById('cartridges');
const statusEl = document.getElementById('status');
const probeEl = document.getElementById('probe');
const targetEl = document.getElementById('target');
const sounds = {
  fire: document.getElementById('fire'),
  charge: document.getElementById('charge'),
  reenergize: document.getElementById('reenergize'),
  reload: document.getElementById('reload')
};
let chargePlaying = false;
let dragging = false;
let dragX = 0, dragY = 0;
let pos = JSON.parse(localStorage.getItem('taser10HudPos') || 'null');

function applyPosition() {
  if (!pos) return;
  hud.style.left = pos.x + 'px';
  hud.style.top = pos.y + 'px';
  hud.style.right = 'auto';
  hud.style.bottom = 'auto';
}
applyPosition();

function render(d) {
  hud.classList.remove('hidden');
  carts.innerHTML = '';
  for (let i = 1; i <= 10; i++) {
    const x = document.createElement('span');
    x.className = 'cart ' + (i <= (d.shots ?? 10) ? 'live' : 'fired');
    carts.appendChild(x);
  }
  statusEl.textContent = d.status || 'READY';
  const count = d.connectionCount || 0;
  probeEl.textContent = count ? `${count} PROBE${count === 1 ? '' : 'S'} CONNECTED` : 'NO PROBE';
  targetEl.textContent = d.target || '--';
  statusEl.classList.toggle('pulse', ['FIRING','RELOADING','RE-ENERGIZING'].some(x => (d.status || '').startsWith(x)));
}

function stopCharge() {
  if (!chargePlaying) return;
  sounds.charge.pause();
  sounds.charge.currentTime = 0;
  chargePlaying = false;
}

function play(name, volume) {
  const audio = sounds[name];
  if (!audio) return;
  audio.pause();
  audio.currentTime = 0;
  audio.volume = Math.max(0, Math.min(1, volume ?? 0.75));
  const p = audio.play();
  if (p && p.catch) p.catch(() => {});
}

window.addEventListener('message', e => {
  const d = e.data || {};
  if (d.action === 'show' || d.action === 'update') render(d);
  if (d.action === 'hide') { hud.classList.add('hidden'); stopCharge(); }
  if (d.action === 'sound') play(d.name || 'fire', d.volume);
  if (d.action === 'aim') {
    if (d.active && !chargePlaying) {
      chargePlaying = true;
      sounds.charge.currentTime = 0;
      sounds.charge.loop = true;
      sounds.charge.volume = 0.75;
      const p = sounds.charge.play();
      if (p && p.catch) p.catch(() => { chargePlaying = false; });
    } else if (!d.active) stopCharge();
  }
});

hud.addEventListener('mousedown', e => {
  if (e.button !== 0) return;
  dragging = true;
  const r = hud.getBoundingClientRect();
  dragX = e.clientX - r.left;
  dragY = e.clientY - r.top;
  e.preventDefault();
});
window.addEventListener('mousemove', e => {
  if (!dragging) return;
  const x = Math.max(0, Math.min(window.innerWidth - hud.offsetWidth, e.clientX - dragX));
  const y = Math.max(0, Math.min(window.innerHeight - hud.offsetHeight, e.clientY - dragY));
  hud.style.left = x + 'px';
  hud.style.top = y + 'px';
  hud.style.right = 'auto';
  hud.style.bottom = 'auto';
  pos = {x, y};
});
window.addEventListener('mouseup', () => {
  if (!dragging) return;
  dragging = false;
  localStorage.setItem('taser10HudPos', JSON.stringify(pos));
});

// Double-click the HUD to reset its position.
hud.addEventListener('dblclick', () => {
  pos = null;
  localStorage.removeItem('taser10HudPos');
  hud.style.left = '';
  hud.style.top = '';
  hud.style.right = '3.2vw';
  hud.style.bottom = '8.5vh';
});
