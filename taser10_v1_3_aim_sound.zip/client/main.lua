local weaponHash = joaat(Config.Weapon)
local shots = Config.MaxShots
local lastShot = 0
local reloading = false
local chargePlaying = false
local activeProbes = {}

local function nui(action, data)
    if not Config.EnableNUI then return end
    data = data or {}
    data.action = action
    SendNUIMessage(data)
end

local function status(probe, target, text)
    nui('update', {shots=shots, max=Config.MaxShots, probe=probe or false, target=target or '--', status=text or 'READY'})
end

local function notify(msg)
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName(msg)
    EndTextCommandThefeedPostTicker(false, false)
end

local function stopCharge()
    if chargePlaying then
        nui('chargeStop')
        chargePlaying = false
    end
end

local function startCharge()
    if not Config.PlayChargeWhileAiming or chargePlaying then return end
    nui('chargeStart', {volume=Config.ChargeVolume})
    chargePlaying = true
end

local function playTaserSound()
    nui('fireSound', {volume=Config.SoundVolume})
end

local function reloadTaser()
    if reloading or shots >= Config.MaxShots then return end
    stopCharge()
    reloading = true
    status(false, '--', 'RELOADING')
    CreateThread(function()
        Wait(Config.ReloadTime)
        shots = Config.MaxShots
        SetPedAmmo(PlayerPedId(), weaponHash, 1)
        reloading = false
        status(false, '--', 'READY')
        notify('~b~TASER 10~s~ ready — 10 cartridges available')
    end)
end

local function stunPed(ped)
    if not DoesEntityExist(ped) or IsEntityDead(ped) then return end
    local player = NetworkGetPlayerIndexFromPed(ped)
    if player ~= -1 then
        TriggerServerEvent('taser10:stun', GetPlayerServerId(player), Config.StunDuration)
    end
end

RegisterNetEvent('taser10:applyStun', function(duration)
    local ped = PlayerPedId()
    SetPedToRagdoll(ped, duration, duration, 0, false, false, false)
    ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.12)
end)

CreateThread(function()
    while true do
        local wait = 250
        local ped = PlayerPedId()
        local weapon = GetSelectedPedWeapon(ped)

        if weapon == weaponHash then
            wait = 0
            nui('show', {shots=shots, max=Config.MaxShots, probe=#activeProbes > 0, target='--', status=reloading and 'RELOADING' or 'READY'})

            -- Keep GTA's native stun-gun aim/fire controls active.
            if reloading then
                DisablePlayerFiring(PlayerId(), true)
            end

            if IsPlayerFreeAiming(PlayerId()) and not reloading and shots > 0 then
                startCharge()
            else
                stopCharge()
            end

            if IsControlJustPressed(0, 45) then -- R
                reloadTaser()
            end

            -- Native stungun fires normally; we count each actual shot.
            if IsPedShooting(ped) then
                stopCharge()
                local now = GetGameTimer()

                if reloading or shots <= 0 or (now - lastShot) < Config.FireCooldown then
                    DisablePlayerFiring(PlayerId(), true)
                else
                    lastShot = now
                    shots = shots - 1
                    playTaserSound()
                    status(false, '--', 'FIRING')

                    local hit, entity = GetEntityPlayerIsFreeAimingAt(PlayerId())
                    if hit and DoesEntityExist(entity) and IsEntityAPed(entity) then
                        local dist = #(GetEntityCoords(ped) - GetEntityCoords(entity))
                        if dist <= Config.MaxRange then
                            stunPed(entity)
                            activeProbes[#activeProbes + 1] = {
                                target = entity,
                                created = now,
                                expires = now + Config.StunDuration
                            }
                            local targetPlayer = NetworkGetPlayerIndexFromPed(entity)
                            local name = (targetPlayer ~= -1 and GetPlayerName(targetPlayer)) or 'TARGET'
                            status(true, name, 'CONNECTED')
                        end
                    end

                    -- Keep the native weapon loaded enough for the next trigger pull.
                    -- Our Lua counter is the authoritative 10-cartridge count.
                    SetPedAmmo(ped, weaponHash, 1)

                    if shots == 0 then
                        notify('~r~TASER 10 EMPTY~s~ — press ~y~R~s~ to reload')
                    end
                end
            end
        else
            stopCharge()
            nui('hide')
        end

        Wait(wait)
    end
end)

CreateThread(function()
    while true do
        Wait(0)
        if Config.EnableProbeEffects then
            local ped = PlayerPedId()
            for i = #activeProbes, 1, -1 do
                local p = activeProbes[i]
                if GetGameTimer() > p.expires or not DoesEntityExist(p.target) then
                    table.remove(activeProbes, i)
                else
                    local a = GetEntityCoords(ped)
                    local b = GetEntityCoords(p.target)
                    DrawLine(a.x, a.y, a.z + .75, b.x, b.y, b.z + .75, 120, 190, 255, 180)
                end
            end
        end
    end
end)

exports('GetShots', function() return shots end)

exports('GiveTaser10', function()
    local ped = PlayerPedId()
    GiveWeaponToPed(ped, weaponHash, 1, false, true)
    SetPedAmmo(ped, weaponHash, 1)
    SetCurrentPedWeapon(ped, weaponHash, true)
    shots = Config.MaxShots
    reloading = false
    status(false, '--', 'READY')
end)

RegisterCommand('taser10', function()
    exports['taser10']:GiveTaser10()
end, false)

AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then
        stopCharge()
        nui('hide')
    end
end)
