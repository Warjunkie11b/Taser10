Config = {}

-- Uses GTA's native stun-gun runtime so aiming/firing/animations work reliably.
-- The supplied custom YDR/YTD remain the weapon assets.
Config.Weapon = 'WEAPON_STUNGUN'
Config.MaxShots = 10
Config.MaxRange = 30.0
Config.FireCooldown = 800
Config.ReloadTime = 1800
Config.StunDuration = 4500
Config.EnableNUI = true
Config.EnableProbeEffects = true
Config.SoundVolume = 0.75
Config.ChargeVolume = 0.35
Config.PlayChargeWhileAiming = true
