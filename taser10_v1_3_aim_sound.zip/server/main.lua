RegisterNetEvent('taser10:stun', function(target, duration)
    local src = source
    if type(target) ~= 'number' or type(duration) ~= 'number' then return end
    if target < 0 or duration < 0 or duration > 15000 then return end
    TriggerClientEvent('taser10:applyStun', target, math.floor(duration))
end)
