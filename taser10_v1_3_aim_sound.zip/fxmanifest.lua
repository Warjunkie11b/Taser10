fx_version 'cerulean'
game 'gta5'

author 'TASER 10 FiveM Resource'
description 'Standalone TASER 10-style gameplay resource'
version '1.3.0'

files {
    'data/weapons.meta',
    'nui/index.html',
    'nui/style.css',
    'nui/app.js',
    'sounds/taser_fire.wav',
    'sounds/taser_charge.wav'
}

data_file 'WEAPONINFO_FILE_PATCH' 'data/weapons.meta'

ui_page 'nui/index.html'

client_scripts {
    'config.lua',
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}
