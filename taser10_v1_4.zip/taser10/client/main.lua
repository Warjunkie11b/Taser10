local weaponHash = joaat(Config.Weapon)
local shots = Config.MaxShots
local lastShot = 0
local reloading = false
local connectedTarget = nil
local connectedTargetName = '--'
local connectedUntil = 0
local charging = false

local function nui(action, data)
    if not Config.EnableNUI then return end
    data = data or {}
    data.action = action
    SendNUIMessage(data)
end

local function status(probe, target, text)
    nui('update', {
        shots = shots,
        probe = probe or false,
        target = target or '--',
        status = text or 'READY'
    })
end

local function notify(msg)
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName(msg)
    EndTextCommandThefeedPostTicker(false, false)
end

local function playSound(name, volume)
    if not Config.EnableNUI then return end
    SendNUIMessage({ action = 'sound', name = name, volume = volume or Config.SoundVolume })
end

local function getAimedPed()
    local ok, entity = GetEntityPlayerIsFreeAimingAt(PlayerId())
    if ok and DoesEntityExist(entity) and IsEntityAPed(entity) and not IsEntityDead(entity) then
        return entity
    end
    return nil
end

local function getTargetName(ped)
    local player = NetworkGetPlayerIndexFromPed(ped)
    if player ~= -1 then return GetPlayerName(player) or 'TARGET' end
    return 'TARGET'
end

local function stunPed(ped, duration)
    if not DoesEntityExist(ped) or IsEntityDead(ped) then return false end
    local player = NetworkGetPlayerIndexFromPed(ped)
    if player ~= -1 then
        TriggerServerEvent('taser10:stun', GetPlayerServerId(player), duration)
    else
        SetPedToRagdoll(ped, duration, duration, 0, false, false, false)
    end
    return true
end

local function reloadTaser()
    if reloading or shots >= Config.MaxShots then return end
    reloading = true
    connectedTarget = nil
    connectedTargetName = '--'
    connectedUntil = 0
    status(false, '--', 'RELOADING')
    playSound('reload', Config.SoundVolume)
    CreateThread(function()
        Wait(Config.ReloadTime)
        shots = Config.MaxShots
        reloading = false
        status(false, '--', 'READY')
        notify('~b~TASER 10~s~ reloaded — 10 cartridges available')
    end)
end

local function fireTaser()
    if reloading or shots <= 0 then
        if shots <= 0 then notify('~r~TASER 10 EMPTY~s~ — press ~y~R~s~ to reload') end
        return
    end

    local now = GetGameTimer()
    if now - lastShot < Config.FireCooldown then return end
    lastShot = now
    shots = shots - 1
    playSound('fire', Config.SoundVolume)
    status(false, '--', 'FIRING')

    local ped = PlayerPedId()
    local target = getAimedPed()
    if target then
        local dist = #(GetEntityCoords(ped) - GetEntityCoords(target))
        if dist <= Config.MaxRange then
            local name = getTargetName(target)
            if stunPed(target, Config.StunDuration) then
                connectedTarget = target
                connectedTargetName = name
                connectedUntil = GetGameTimer() + Config.StunDuration
                status(true, name, 'CONNECTED')
            end
        else
            status(false, '--', 'OUT OF RANGE')
            Wait(400)
        end
    else
        status(false, '--', 'NO CONNECTION')
        Wait(400)
    end

    if shots == 0 then
        notify('~r~TASER 10 EMPTY~s~ — press ~y~R~s~ to reload')
    elseif connectedTarget then
        status(true, connectedTargetName, 'CONNECTED')
    else
        status(false, '--', 'READY')
    end
end

local function reEnergize()
    if reloading or not connectedTarget then return end
    if not DoesEntityExist(connectedTarget) or IsEntityDead(connectedTarget) then
        connectedTarget = nil
        connectedTargetName = '--'
        connectedUntil = 0
        status(false, '--', 'READY')
        return
    end

    if GetGameTimer() > connectedUntil then
        -- Keep the connection available for a gameplay re-energize even after the first cycle.
        connectedUntil = GetGameTimer() + Config.ReEnergizeDuration
    end

    playSound('reenergize', Config.SoundVolume)
    stunPed(connectedTarget, Config.ReEnergizeDuration)
    connectedUntil = GetGameTimer() + Config.ReEnergizeDuration
    status(true, connectedTargetName, 'RE-ENERGIZING')
    CreateThread(function()
        Wait(Config.ReEnergizeDuration)
        if connectedTarget and DoesEntityExist(connectedTarget) then
            status(true, connectedTargetName, 'CONNECTED')
        end
    end)
end

RegisterNetEvent('taser10:applyStun', function(duration)
    local ped = PlayerPedId()
    SetPedToRagdoll(ped, duration, duration, 0, false, false, false)
    ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.12)
    CreateThread(function()
        local finish = GetGameTimer() + duration
        while GetGameTimer() < finish do
            DisablePlayerFiring(PlayerId(), true)
            DisableControlAction(0, 24, true)
            DisableControlAction(0, 25, true)
            DisableControlAction(0, 37, true)
            DisableControlAction(0, 45, true)
            Wait(0)
        end
    end)
end)

CreateThread(function()
    while true do
        local wait = 250
        local ped = PlayerPedId()
        local weapon = GetSelectedPedWeapon(ped)

        if weapon == weaponHash then
            wait = 0
            nui('show', {
                shots = shots,
                probe = connectedTarget ~= nil,
                target = connectedTargetName,
                status = reloading and 'RELOADING' or 'READY'
            })

            if reloading then
                DisablePlayerFiring(PlayerId(), true)
            end

            -- R = reload
            if IsControlJustPressed(0, 45) then reloadTaser() end

            -- G = re-energize connected probes, matching the TASER 10's re-energize function.
            if IsControlJustPressed(0, 47) then reEnergize() end

            -- Let GTA handle aiming, but intercept the actual trigger so the stock Stun Gun shot/audio never fires.
            if IsPlayerFreeAiming(PlayerId()) then
                charging = true
                nui('aim', { active = true })
                DisableControlAction(0, 24, true) -- INPUT_ATTACK
                DisableControlAction(0, 257, true) -- INPUT_ATTACK2
                if IsDisabledControlJustPressed(0, 24) then
                    fireTaser()
                end
            else
                if charging then
                    charging = false
                    nui('aim', { active = false })
                end
            end
        else
            if charging then
                charging = false
                nui('aim', { active = false })
            end
            nui('hide')
        end
        Wait(wait)
    end
end)

exports('GetShots', function() return shots end)
exports('GiveTaser10', function()
    local ped = PlayerPedId()
    GiveWeaponToPed(ped, weaponHash, Config.MaxShots, false, true)
    SetPedAmmo(ped, weaponHash, Config.MaxShots)
    shots = Config.MaxShots
    status(false, '--', 'READY')
end)

RegisterCommand('taser10', function()
    exports['taser10']:GiveTaser10()
end, false)
