const hud = document.getElementById('hud');
const carts = document.getElementById('cartridges');
const statusEl = document.getElementById('status');
const probeEl = document.getElementById('probe');
const targetEl = document.getElementById('target');
const sounds = {
  fire: document.getElementById('fire'),
  charge: document.getElementById('charge'),
  reenergize: document.getElementById('reenergize'),
  reload: document.getElementById('reload')
};
let chargePlaying = false;

function render(d) {
  hud.classList.remove('hidden');
  carts.innerHTML = '';
  for (let i = 1; i <= 10; i++) {
    const x = document.createElement('span');
    x.className = 'cart ' + (i <= (d.shots ?? 10) ? 'live' : 'fired');
    carts.appendChild(x);
  }
  statusEl.textContent = d.status || 'READY';
  probeEl.textContent = d.probe ? 'PROBE CONNECTED' : 'NO PROBE';
  targetEl.textContent = d.target || '--';
  statusEl.classList.toggle('pulse', ['FIRING','RELOADING','RE-ENERGIZING'].includes(d.status));
}

function stopCharge() {
  if (!chargePlaying) return;
  sounds.charge.pause();
  sounds.charge.currentTime = 0;
  chargePlaying = false;
}

function play(name, volume) {
  const audio = sounds[name];
  if (!audio) return;
  if (name !== 'charge') audio.pause();
  audio.currentTime = 0;
  audio.volume = Math.max(0, Math.min(1, volume ?? 0.75));
  audio.play().catch(() => {});
}

window.addEventListener('message', e => {
  const d = e.data || {};
  if (d.action === 'show' || d.action === 'update') render(d);
  if (d.action === 'hide') { hud.classList.add('hidden'); stopCharge(); }
  if (d.action === 'sound') play(d.name || 'fire', d.volume);
  if (d.action === 'aim') {
    if (d.active && !chargePlaying) {
      chargePlaying = true;
      sounds.charge.currentTime = 0;
      sounds.charge.volume = 0.65;
      sounds.charge.play().catch(() => { chargePlaying = false; });
    } else if (!d.active) stopCharge();
  }
});
