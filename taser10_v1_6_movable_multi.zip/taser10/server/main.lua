RegisterNetEvent('taser10:stun', function(targetId, duration)
    local src = source
    targetId = tonumber(targetId)
    duration = tonumber(duration) or 5000

    if not targetId or targetId == src then return end
    if duration < 500 or duration > 15000 then duration = 5000 end

    TriggerClientEvent('taser10:applyStun', targetId, duration)
end)
