RegisterNetEvent('taser10:stun', function(targetId, duration)
    local src = source
    targetId = tonumber(targetId)
    duration = tonumber(duration) or 5000

    if not targetId or targetId == src then return end
    if duration < 500 or duration > 15000 then duration = 5000 end

    TriggerClientEvent('taser10:applyStun', targetId, duration)
end)


RegisterNetEvent('taser10:aimAudio', function(active)
    local src = source
    TriggerClientEvent('taser10:remoteAimSound', -1, src, active == true)
end)


local recentDischarges = {}
local HISTORY_MS = 60000

local function pruneDischarges()
    local now = GetGameTimer()
    for i = #recentDischarges, 1, -1 do
        if now - recentDischarges[i].time > HISTORY_MS then
            table.remove(recentDischarges, i)
        end
    end
end

RegisterNetEvent('taser10:discharged', function()
    local src = source
    pruneDischarges()
    local entry = {
        serverId = src,
        name = GetPlayerName(src) or ('Officer #' .. tostring(src)),
        time = GetGameTimer()
    }
    recentDischarges[#recentDischarges + 1] = entry
    while #recentDischarges > 25 do table.remove(recentDischarges, 1) end
    TriggerClientEvent('taser10:dischargeNotice', -1, entry)
end)

RegisterNetEvent('taser10:getDischargeHistory', function()
    local src = source
    pruneDischarges()
    TriggerClientEvent('taser10:dischargeHistory', src, recentDischarges)
end)
