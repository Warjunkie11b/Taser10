local weaponHash = joaat(Config.Weapon)
local shots = Config.MaxShots
local lastShot = 0
local reloading = false
local connections = {}
local connectedTarget = nil
local connectedTargetName = '--'
local connectedUntil = 0
local charging = false
local hudVisible = false

local function nui(action, data)
    if not Config.EnableNUI then return end
    data = data or {}
    data.action = action
    SendNUIMessage(data)
end

local function connectionCount()
    local n = 0
    for _, c in pairs(connections) do
        if DoesEntityExist(c.ped) and not IsEntityDead(c.ped) then n = n + 1 end
    end
    return n
end

local function syncConnectionDisplay(text)
    local names = {}
    for _, c in pairs(connections) do
        if DoesEntityExist(c.ped) and not IsEntityDead(c.ped) then names[#names+1] = c.name end
    end
    table.sort(names)
    nui('update', {
        shots = shots,
        probe = #names > 0,
        target = (#names > 0 and table.concat(names, ', ')) or '--',
        status = text or (#names > 0 and ('CONNECTED: '..#names) or 'READY'),
        connectionCount = #names
    })
end

local function notify(msg)
    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName(msg)
    EndTextCommandThefeedPostTicker(false, false)
end

local function playSound(name, volume)
    if not Config.EnableNUI then return end
    SendNUIMessage({ action = 'sound', name = name, volume = volume or Config.SoundVolume })
end

local function getAimedPed()
    local ok, entity = GetEntityPlayerIsFreeAimingAt(PlayerId())
    if ok and DoesEntityExist(entity) and IsEntityAPed(entity) and not IsEntityDead(entity) then
        return entity
    end
    return nil
end

local function getTargetName(ped)
    local player = NetworkGetPlayerIndexFromPed(ped)
    if player ~= -1 then return GetPlayerName(player) or 'TARGET' end
    return 'TARGET'
end

local function stunPed(ped, duration)
    if not DoesEntityExist(ped) or IsEntityDead(ped) then return false end
    local player = NetworkGetPlayerIndexFromPed(ped)
    if player ~= -1 then
        TriggerServerEvent('taser10:stun', GetPlayerServerId(player), duration)
    else
        SetPedToRagdoll(ped, duration, duration, 0, false, false, false)
    end
    return true
end

local function reloadTaser()
    if reloading or shots >= Config.MaxShots then return end
    reloading = true
    connections = {}
    connectedTarget = nil
    connectedTargetName = '--'
    connectedUntil = 0
    nui('update', { shots = shots, probe = connectionCount() > 0, target = connectedTargetName, status = 'RELOADING', connectionCount = connectionCount() })
    playSound('reload', Config.SoundVolume)
    CreateThread(function()
        Wait(Config.ReloadTime)
        shots = Config.MaxShots
        reloading = false
        nui('update', { shots = shots, probe = connectionCount() > 0, target = connectedTargetName, status = 'READY', connectionCount = connectionCount() })
        notify('~b~TASER 10~s~ reloaded — 10 cartridges available')
    end)
end

local function fireTaser()
    if reloading or shots <= 0 then
        if shots <= 0 then notify('~r~TASER 10 EMPTY~s~ — press ~y~R~s~ to reload') end
        return
    end

    local now = GetGameTimer()
    if now - lastShot < Config.FireCooldown then return end
    lastShot = now
    shots = shots - 1

    -- Force the native stun-gun trigger to remain suppressed; the custom NUI sound is played separately.
    playSound('fire', Config.SoundVolume)
    syncConnectionDisplay('FIRING')

    local shooter = PlayerPedId()
    local target = getAimedPed()
    if target then
        local dist = #(GetEntityCoords(shooter) - GetEntityCoords(target))
        if dist <= Config.MaxRange then
            local name = getTargetName(target)
            if stunPed(target, Config.StunDuration) then
                local key = NetworkGetPlayerIndexFromPed(target)
                if key == -1 then key = 'ped:' .. tostring(target) end
                connections[key] = {
                    ped = target,
                    name = name,
                    untilTime = GetGameTimer() + Config.StunDuration
                }
                connectedTarget = target
                connectedTargetName = name
                connectedUntil = GetGameTimer() + Config.StunDuration
                syncConnectionDisplay('CONNECTED: '..connectionCount())
            end
        else
            syncConnectionDisplay('OUT OF RANGE')
        end
    else
        syncConnectionDisplay('NO CONNECTION')
    end

    if shots == 0 then
        notify('~r~TASER 10 EMPTY~s~ — press ~y~R~s~ to reload')
    end
end

local function reEnergize()
    if reloading then return end

    local valid = {}
    for key, c in pairs(connections) do
        if DoesEntityExist(c.ped) and not IsEntityDead(c.ped) then
            valid[#valid+1] = c
        else
            connections[key] = nil
        end
    end

    if #valid == 0 then
        syncConnectionDisplay('READY')
        return
    end

    playSound('reenergize', Config.SoundVolume)
    syncConnectionDisplay('RE-ENERGIZING: '..#valid)

    for _, c in ipairs(valid) do
        stunPed(c.ped, Config.ReEnergizeDuration)
        c.untilTime = GetGameTimer() + Config.ReEnergizeDuration
    end

    CreateThread(function()
        Wait(Config.ReEnergizeDuration)
        syncConnectionDisplay('CONNECTED: '..connectionCount())
    end)
end

RegisterNetEvent('taser10:applyStun', function(duration)
    local ped = PlayerPedId()
    SetPedToRagdoll(ped, duration, duration, 0, false, false, false)
    ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.12)
    CreateThread(function()
        local finish = GetGameTimer() + duration
        while GetGameTimer() < finish do
            DisablePlayerFiring(PlayerId(), true)
            DisableControlAction(0, 24, true)
            DisableControlAction(0, 25, true)
            DisableControlAction(0, 37, true)
            DisableControlAction(0, 45, true)
            Wait(0)
        end
    end)
end)

local function showHud()
    if hudVisible then return end
    hudVisible = true
    nui('show', {
        shots = shots,
        probe = connectionCount() > 0,
        target = connectedTargetName,
        status = reloading and 'RELOADING' or 'READY'
    })
end

local function hideHud()
    if not hudVisible then return end
    hudVisible = false
    nui('hide')
    if charging then
        charging = false
        nui('aim', { active = false })
    end
end

CreateThread(function()
    while true do
        local wait = 250
        local ped = PlayerPedId()
        local weapon = GetSelectedPedWeapon(ped)

        if weapon == weaponHash and not IsEntityDead(ped) then
            wait = 0
            showHud()

            if reloading then
                DisablePlayerFiring(PlayerId(), true)
            end

            -- R = reload. Use disabled-control detection so reload remains reliable
            -- even if another resource temporarily blocks the normal input.
            if IsControlJustPressed(0, 45) or IsDisabledControlJustPressed(0, 45) then
                reloadTaser()
            end

            -- G = re-energize all currently connected targets.
            if IsControlJustPressed(0, 47) or IsDisabledControlJustPressed(0, 47) then
                reEnergize()
            end

            -- Keep native aiming animation/camera intact. Suppress only the actual
            -- attack input so the native stun-gun projectile/audio does not fire.
            if IsPlayerFreeAiming(PlayerId()) then
                if not charging then
                    charging = true
                    nui('aim', { active = true, volume = Config.SoundVolume })
                end
                DisableControlAction(0, 24, true)
                if IsDisabledControlJustPressed(0, 24) then
                    fireTaser()
                end
            elseif charging then
                charging = false
                nui('aim', { active = false })
            end
        else
            hideHud()
        end
        Wait(wait)
    end
end)

AddEventHandler('onClientResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end
    hideHud()
    SetNuiFocus(false, false)
    SetNuiFocusKeepInput(false)
end)

exports('GetShots', function() return shots end)
exports('GiveTaser10', function()
    local ped = PlayerPedId()
    GiveWeaponToPed(ped, weaponHash, Config.MaxShots, false, true)
    SetPedAmmo(ped, weaponHash, Config.MaxShots)
    shots = Config.MaxShots
    connections = {}
    syncConnectionDisplay('READY')
end)

RegisterCommand('taser10', function()
    exports['taser10']:GiveTaser10()
end, false)

RegisterCommand('taser10check', function()
    local ped = PlayerPedId()
    local current = GetSelectedPedWeapon(ped)
    notify(('~b~TASER 10~s~ weapon hash: %s | current: %s'):format(weaponHash, current))
end, false)

RegisterCommand('taser10debug', function()
    notify(('~b~TASER 10~s~ | cartridges: %d/10 | reloading: %s | aiming: %s'):format(shots, tostring(reloading), tostring(IsPlayerFreeAiming(PlayerId()))))
end, false)
